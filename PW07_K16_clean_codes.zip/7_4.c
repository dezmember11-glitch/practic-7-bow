#include <stdio.h>

void assign_first(double *a, double *b, double *c)
{
    *b = *a;
    *c = *a;
}

int main(void)
{
    double a, b, c;

    printf("Enter three numbers: ");
    if (scanf("%lf %lf %lf", &a, &b, &c) != 3) {
        printf("Invalid input.\n");
        return 0;
    }

    printf("Before: a = %.2f, b = %.2f, c = %.2f\n", a, b, c);
    assign_first(&a, &b, &c);
    printf("After:  a = %.2f, b = %.2f, c = %.2f\n", a, b, c);

    return 0;
}
