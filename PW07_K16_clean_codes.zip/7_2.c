#include <stdio.h>
#include <ctype.h>

int main(void)
{
    int ch;
    int a = 0, b = 0, c = 0;
    unsigned long long matches = 0;
    unsigned long long total = 0;

    while ((ch = getchar()) != EOF) {
        total++;

        if (!isalpha((unsigned char)ch)) {
            a = b = c = 0;
            continue;
        }

        if (a == 't' && b == 'i' && c == 'o' && ch == 'n') {
            matches++;
        }

        a = b;
        b = c;
        c = ch;
    }

    printf("Occurrences of tion: %llu\n", matches);
    printf("Total characters: %llu\n", total);

    return 0;
}
