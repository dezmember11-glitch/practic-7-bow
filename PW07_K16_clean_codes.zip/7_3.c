#include <stdio.h>
#include <math.h>

static double factorial(double n)
{
    double result = 1.0;

    for (int i = 2; i <= (int)n; i++) {
        result *= i;
    }

    return result;
}

double sum_factorials(double a, double b)
{
    return factorial(a) + factorial(b);
}

int main(void)
{
    double a, b;
    int status;

    while (1) {
        printf("Enter two non-negative integers (0 to 170): ");
        status = scanf("%lf %lf", &a, &b);

        if (status == EOF) {
            break;
        }

        if (status != 2) {
            int ch;
            printf("Invalid input.\n");
            while ((ch = getchar()) != '\n' && ch != EOF) {
            }
            if (ch == EOF) {
                break;
            }
            continue;
        }

        if (!isfinite(a) || !isfinite(b) ||
            a < 0 || b < 0 || a > 170 || b > 170 ||
            floor(a) != a || floor(b) != b) {
            printf("Both numbers must be integers from 0 to 170.\n");
            continue;
        }

        printf("Sum of factorials: %.4f\n", sum_factorials(a, b));
    }

    return 0;
}
