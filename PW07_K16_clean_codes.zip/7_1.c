#include <stdio.h>

int main(void)
{
    int ch;

    while ((ch = getchar()) != EOF) {
        if (ch < 128 && ch % 2 != 0) {
            putchar(ch);
        }
    }

    return 0;
}
