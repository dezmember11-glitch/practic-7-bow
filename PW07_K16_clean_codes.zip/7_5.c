#include <stdio.h>

unsigned long long sum_squares_recursive(unsigned int n)
{
    if (n == 0) {
        return 0;
    }

    return (unsigned long long)n * n + sum_squares_recursive(n - 1);
}

unsigned long long sum_squares_iterative(unsigned int n)
{
    unsigned long long sum = 0;

    for (unsigned int i = 1; i <= n; i++) {
        sum += (unsigned long long)i * i;
    }

    return sum;
}

int main(void)
{
    int n;

    printf("Enter N (0 to 10000): ");
    if (scanf("%d", &n) != 1 || n < 0 || n > 10000) {
        printf("Invalid N.\n");
        return 0;
    }

    printf("Recursive result: %llu\n", sum_squares_recursive((unsigned int)n));
    printf("Iterative result: %llu\n", sum_squares_iterative((unsigned int)n));

    return 0;
}
